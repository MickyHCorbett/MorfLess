
var PostLists = window.PostLists || {};

(function postListsScopeWrapper($) {

  // ====================================

  $(function onDocReady() {

    var scriptRef;
    var js_constant = '';


    $('script').each(function(index){
      if ( $(this).attr('data-js-constant-name') !== undefined )
        scriptRef = $(this).attr('data-js-constant-name');
        // set local constant
        js_constant = window[scriptRef];
    });

    // create postlists
    $.each(js_constant.entries, function (listIndex,obj) {
        handlePostLists(listIndex,obj,js_constant)
    }); // end of postlists loop

  });

}(jQuery));

//
//
//
//
function handlePostLists(listIndex,obj,js_constant) {

    var startData, endData;
    var pageSelectorIndex;
    var postList, postEntries;
    var postlistData = '';
    var listHeight = 0;

    var ppp = parseInt(obj.posts_per_page);
    var pageSelectorIndex = 0;
    var posts = obj.posts;
    var sticky = obj.sticky

    var stickyElements = createPostListEntries(sticky,0,(sticky.length - 1));
    var listElements = createPostList(posts,stickyElements,listIndex,js_constant,pageSelectorIndex,ppp);

    var selectorElements = $(listElements.postlist_page_ident_class);

    var listPosition, selectorPosition;

    // fix height of list entries for change in selection
    postList = $(listElements.postlist_ident_class);
    postEntries = postList.find('.pm-post-content');
    setPostlistHeight(postList,postEntries,ppp);

    $( window ).resize(function() {
      setPostlistHeight(postList,postEntries,ppp);
    });

    // bind to each pagination element and update list on page number click
    $.each(selectorElements, function (index,obj) {

        $(this).click( function() {

          pageSelectorIndex = index;
          startData = ppp*index;
          endData = startData + ppp - 1;

          logPostlistPageNumberClick(pageSelectorIndex+1,listElements.postlist_page_ident_class);
          $(this).addClass(js_constant.page_numbers_selected_class);

          // update list based on new selection
          if (stickyElements !== undefined)  {
            postlistData = stickyElements + '\n';
          }
          postlistData += createPostListEntries(posts,startData,endData);
          postList.html(postlistData);

          // clear previous selected class
          $.each(selectorElements, function (index,obj) {
            if ( index !== pageSelectorIndex ) {
              $(this).removeClass(js_constant.page_numbers_selected_class);
            }
          });

          // if window resizes recalculate height
          $( window ).resize(function() {
            postEntries = postList.find('.pm-post-content');
            setPostlistHeight(postList,postEntries,ppp);
          });

          // scroll back to top of list
          selectorPosition = $(listElements.postlist_page_ident_class).offset();
          listPosition = $(listElements.postlist_ident_class).offset();
          scrollListToTop( selectorPosition,listPosition);


        });
      });

}
//
//
function scrollListToTop(selectorPosition,listPosition) {

  var body = $('html, body');
  var headerHeight = $('#header-fixed').outerHeight(true)+48;
  body.stop().animate({scrollTop:listPosition.top-headerHeight}, 300, 'swing', function() {
     console.log('Back to :' + listPosition.top);
  });

}


function setPostlistHeight(postList,postEntries,ppp) {

  // fix height of list entries for change in selection
  let listHeight = 0;

  $.each(postEntries, function (index,obj) {
    if (index === 0) {
      listHeight += $(this).outerHeight(true);
    }
  });
  listHeight = listHeight*ppp;
  postList.css('height', listHeight);

}
//
//
function logPostlistPageNumberClick(index,listClass) {
  console.log('Page number ' + index + ' in ' + listClass + ' clicked');
}
//
function createPostList(posts,sticky,index,js_constant,selectorIndex,ppp){

  var postlist_ident = js_constant.identifier + (index+1).toString();
  var postlist_ident_class = '.' + postlist_ident;
  var postlist_pagination_class = '.' + js_constant.pagination_class;
  var postlist_page_ident = postlist_ident + js_constant.pagination_selector_id;
  var postlist_page_ident_class =  '.' +  postlist_page_ident;

  var entryData = '';
  var paginationData;
  var paginationHtml;

  var startData = ppp*selectorIndex;
  var endData = startData + ppp - 1;

  if (sticky !== undefined)  {
    entryData = sticky + '\n';
  }
  entryData += createPostListEntries(posts,startData,endData);
  paginationHtml = createPostlistPagination(posts,ppp,js_constant,postlist_page_ident);

  if (paginationHtml !== undefined) {
    // create pagination buttons and initial data
    paginationData = paginationHtml;
  }

  $(postlist_ident_class).html(entryData);
  $(postlist_pagination_class).each(function(index){
    if ( $(this).attr('data-postlist-name') === postlist_ident )
      $(this).html(paginationHtml);
  });

  var outValues = {
    postlist_ident_class: postlist_ident_class,
    postlist_page_ident_class: postlist_page_ident_class
  }
  return outValues;
}

//

function createPostlistPagination(array_data,ppp,js_constant,ident){
  var outHtml = '';
  var paginationEntry = '';
  var i = 1;
  var ident_sub = js_constant.pagination_number_ident;
  var number_sub = js_constant.pagination_number_sub;
  var total_pages = 1;

  ident_first = ident + ' ' + js_constant.page_numbers_selected_class;

  if (array_data.length > ppp){
    if (ppp === 1) {
      total_pages = array_data.length;
    } else {
      total_pages = Math.floor((array_data.length-1)/ppp)+1;
    }

    for (i = 1; i <= total_pages; i++) {
      if (i === 1) {
        paginationEntry = js_constant.pagination_element.replace(ident_sub,ident_first);
      } else {
        paginationEntry = js_constant.pagination_element.replace(ident_sub,ident);
      }
      paginationEntry = paginationEntry.replace(number_sub,i);
      outHtml += paginationEntry;
    }
    console.log('Postlist pagination added for list: ' + ident);
  }

  return outHtml;
}

function createPostListEntries(array_data,start,end){
  var i = 0;
  var entryData = '';
  var entry = '';

  if (array_data !== undefined) {

    for (i = start; i <= end; i++) {
      entry = $.trim(array_data[i]);

      if (entry !== undefined){
        entryData += entry + "\n";
      }

    }
  }

  return $.trim(entryData);
}
