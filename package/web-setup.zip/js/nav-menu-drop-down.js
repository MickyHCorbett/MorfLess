( function( $ ) {
// when responsive icon is clicked - show menu
    //
  $( '.pm-responsive-icon' ).on('click' ,function () {
      $( '.pm-nav-menu-search' ).slideToggle();
  });
//
// if responsive icon displayed initialise to hide menu
  $( window ).resize(function() {
    if ($('.pm-responsive-icon').css('display') === 'block') {
        $( '.pm-nav-menu-search' ).css('display', 'none');
    } else {
        $( '.pm-nav-menu-search' ).css('display', 'block');
    }
  });
} )( jQuery );
