
var Pagination = window.Pagination || {};

(function paginationScopeWrapper($) {

  // ====================================

  $(function onDocReady() {

    var scriptRef;
    var pg_constant;


    $('script').each(function(index){
      if ( $(this).attr('data-pagination-constant-name') !== undefined )
        scriptRef = $(this).attr('data-pagination-constant-name');
        // set local constant
        pg_constant = window[scriptRef];
    });

    createPagination(pg_constant);


  });

}(jQuery));

//
function createPagination(pg_constant){

  var ident = '.pm-post-pagination';
  var entryData = $.trim(pg_constant.pagination);
  $(ident).html(entryData);

}
