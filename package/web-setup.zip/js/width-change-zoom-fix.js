( function( $ ) {
// check if there is a window resize and fix zoom on responsive for 150 ms
	$( window ).resize(function() {
		// set viewport
		$('#viewport-tag').attr('content', 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=yes');
		// wait for 150 ms
		// set normal scaling
		setTimeout(function (){
			$('#viewport-tag').attr('content', 'width=device-width, initial-scale=1, maximum-scale=1.5, user-scalable=yes');
		},150);
	});
//
} )( jQuery );
