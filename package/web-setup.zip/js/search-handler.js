var SearchPage = window.SearchPage || {};

(function searchPageScopeWrapper($) {

  // ====================================

  $(function onDocReady() {

    var search_api_url;
    var search_request;
    var reply;

    // get search request from address bar
    var search_url = window.location.href;
    var params = search_url.split('?s=');
    search_request = params[1];
    search_request = search_request.replace(/\+/g,' ');
    var search_request_display = decodeURI( search_request );

    $('.'+_search_config.header_ident).html(_search_config.sub_title + ' ' + search_request_display);
    var searchbar = $('.pm-search-page').find('input');
    searchbar.val(search_request_display);

    getSearchData(search_request_display);

  });

}(jQuery));

function addAjaxSpinner() {
  // adds to bottom of header
  var headerHtml = $('.'+_search_config.header_ident).html();
  headerHtml += '\n\
  \t\t\t<div class="pm-ajax-loader">\n\
  \t\t\t\t<img src="/images/ajax-loader.gif" class="img-responsive" />\n\
  \t\t\t</div>';

  // update
  $('.'+_search_config.header_ident).html(headerHtml);
  $('.pm-ajax-loader').css("visibility", "visible");

}

function setAjaxSpinnerHidden(){
  $('.pm-ajax-loader').css("visibility", "hidden");
}

function getSearchData(searchterm) {
  var encodeEventName = encodeURI(searchterm);
  if ( (searchterm !== undefined) && ( _search_config.api !== 'NONE') ) {
  $.ajax({
      method: 'GET',
      beforeSend: addAjaxSpinner,
      url: _search_config.api + '/' + searchterm,
      contentType: 'application/json',
      success: function success(data, textStatus, jqXHR ){
        console.log('Search term echo: ' +  data.search_term);
        setAjaxSpinnerHidden();
        handleSearchPostLists(data.content,data.search_term);
      },
      error: function ajaxError(jqXHR, textStatus, errorThrown) {
          console.error('Error requesting user data: ', textStatus, ', Details: ', errorThrown);
          console.error('Response: ', jqXHR.responseText);
          setAjaxSpinnerHidden();
      }
    });
  }
}

function handleSearchPostLists(response,searchterm) {

    var startData, endData;
    var pageSelectorIndex;
    var postList, postEntries;
    var postlistData = '';

    const ppp = parseInt(_search_config.posts_per_page);
    console.log('ppp: ' + ppp);

    var pageSelectorIndex = 0;
    var posts = response.entries;
    var sticky = response.sticky;

    // update header
    $('.'+_search_config.header_ident).html(_search_config.sub_title + ' ' + searchterm + ':&nbsp;&nbsp;&nbsp;&nbsp;' + posts.length);

    //console.log('Number of posts: ' + posts.length);
    var stickyElements = createSearchPostListEntries(sticky,0,(sticky.length - 1));
    var listElements = createSearchPostList(posts,stickyElements,pageSelectorIndex);
    var selectorElements = $(listElements.postlist_page_ident_class);

    var listPosition, selectorPosition;
    var firstClick = 0;

    console.log('listElements class: ' + listElements.postlist_ident_class);
    //console.log('ppp: ' + ppp);

    postList = $(listElements.postlist_ident_class);
    postEntries = postList.find('.pm-post-content');
    setSearchPostListHeight(postList,postEntries,ppp);

    $( window ).resize(function() {
      setSearchPostListHeight(postList,postEntries,ppp);
    });

    // bind to each pagination element and update list on page number click
    $.each(selectorElements, function (index,obj) {
        $(this).click( function() {

          pageSelectorIndex = index;
          startData = ppp*index;
          endData = startData + ppp - 1;

          logSearchPostListPageNumberClick(pageSelectorIndex+1,listElements.postlist_page_ident_class);
          $(this).addClass(_search_config.page_numbers_selected_class);

          // update list based on new selection
          if (stickyElements !== undefined)  {
            postlistData = stickyElements + '\n';
          }
          postlistData += createSearchPostListEntries(posts,startData,endData);
          postList.html(postlistData);

          // clear previous selected class
          $.each(selectorElements, function (index,obj) {
            if ( index !== pageSelectorIndex ) {
              $(this).removeClass(_search_config.page_numbers_selected_class);
            }
          });

          // if window resizes recalculate height
          $( window ).resize(function() {
            postEntries = postList.find('.pm-post-content');
            setSearchPostListHeight(postList,postEntries,ppp);
          });

          if (firstClick !== 0) {
            selectorPosition = $(listElements.postlist_page_ident_class).offset();
            listPosition = $(listElements.postlist_ident_class).offset();
            scrollSearchListToTop( selectorPosition,listPosition);
          }

          firstClick = 1;


        });
      });

}
//
//
function scrollSearchListToTop(selectorPosition,listPosition) {

  var body = $('html, body');
  var headerHeight = $('#header-fixed').outerHeight(true)+90;
  body.stop().animate({scrollTop:listPosition.top-headerHeight}, 300, 'swing', function() {
     console.log('Back to :' + listPosition.top);
  });

}

function setSearchPostListHeight(postList,postEntries,ppp) {

  // fix height of list entries for change in selection
  let listHeight = 0;

  $.each(postEntries, function (index,obj) {
    if (index === 0) {
      listHeight += $(this).outerHeight(true);
    }
  });
  listHeight = listHeight*ppp;
  postList.css('height', listHeight);

}

function logSearchPostListPageNumberClick(index,listClass) {
  console.log('Search page number ' + index + ' in ' + listClass + ' clicked');
}
//
function createSearchPostList(posts,sticky,selectorIndex){

  var postlist_ident = _search_config.content_ident;
  var postlist_ident_class = '.' + postlist_ident;
  var postlist_pagination_class = '.' + _search_config.pagination_ident;
  var postlist_page_ident = postlist_ident + _search_config.pagination_selector_id;
  var postlist_page_ident_class =  '.' +  postlist_page_ident;

  const ppp = parseInt(_search_config.posts_per_page);

  var entryData = '';
  var paginationData;
  var paginationHtml;

  var startData = ppp*selectorIndex;
  var endData = startData + ppp - 1;
  console.log('ppp: ' + ppp);

  if (sticky !== undefined)  {
    entryData = sticky + '\n';
  }
  entryData += createSearchPostListEntries(posts,startData,endData);
  console.log('Initial entry data: ' + entryData);
  paginationHtml = createSearchPostListPagination(posts,ppp,postlist_page_ident);

  if (paginationHtml !== undefined) {
    // create pagination buttons and initial data
    paginationData += paginationHtml;
  }


  console.log('Search list class: ' + postlist_ident_class);
  console.log('Search list pagination class: ' + postlist_pagination_class);

  $(postlist_ident_class).html(entryData);
  $(postlist_pagination_class).html(paginationHtml);

  var outValues = {
    postlist_ident_class: postlist_ident_class,
    postlist_page_ident_class: postlist_page_ident_class
  }
  return outValues;
}

//

function createSearchPostListPagination(array_data,ppp,ident){
  var outHtml = '';
  var paginationEntry = '';
  var i = 1;
  var ident_sub = _search_config.pagination_number_ident;
  var number_sub = _search_config.pagination_number_sub;
  var total_pages = 1;

  ident_first = ident + ' ' + _search_config.page_numbers_selected_class;
  console.log('Search posts array length: ' + array_data.length);

  if (array_data.length > ppp){
    //console.log('Array length ' + array_data.length + ' > ' + ppp);
    if (ppp === 1) {
      total_pages = array_data.length;
    } else {
      total_pages = Math.floor((array_data.length-1)/ppp)+1;
    }

    for (i = 1; i <= total_pages; i++) {
      if (i === 1) {
        paginationEntry = _search_config.pagination_element.replace(ident_sub,ident_first);
        //console.log('Adding first search list page button');
      } else {
        paginationEntry = _search_config.pagination_element.replace(ident_sub,ident);
      }
      paginationEntry = paginationEntry.replace(number_sub,i);
      outHtml += paginationEntry;
    }
    console.log('Postlist pagination added for list: ' + ident);
  }

  return outHtml;
}

function createSearchPostListEntries(array_data,start,end){
  var i = 0;
  var entryData = '';
  var entry = '';

  if (array_data !== undefined) {

    for (i = start; i <= end; i++) {

      entry = array_data[i];

      if (entry !== undefined){
        // convert from JSON
        entryData += $.trim( JSON.parse(entry) )+ "\n";
      }

    }
  }

  return $.trim(entryData);
}
